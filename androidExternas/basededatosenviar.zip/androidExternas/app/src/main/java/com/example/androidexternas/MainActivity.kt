package com.example.androidexternas

import android.app.VoiceInteractor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.textclassifier.TextSelection
import android.widget.EditText
import android.widget.TextView
import com.android.volley.Response
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.androidexternas.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    lateinit var enviarnombre:EditText
    lateinit var valor:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding=ActivityMainBinding.inflate(layoutInflater)
        enviarnombre=binding.nombre
        valor=binding.valor
        setContentView(binding.root)
    }

    fun ejecutarServicios(view: View){
        val url="http://192.168.11.146/recibir/recibirdatos.php?nombre="+enviarnombre.text.toString()
        val cola=Volley.newRequestQueue(this)
        val StringRequest = StringRequest(Request.Method.GET, url,Response.Listener<String>
        {
                response -> valor.text="**" +response.toString()
        },
            Response.ErrorListener {valor.setText("error")} )

        cola.add(StringRequest)

    }
}