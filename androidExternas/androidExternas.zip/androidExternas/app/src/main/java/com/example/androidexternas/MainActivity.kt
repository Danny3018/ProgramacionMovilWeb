package com.example.androidexternas

import android.app.VoiceInteractor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.textclassifier.TextSelection
import android.widget.EditText
import android.widget.TextView
import com.android.volley.Response
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.androidexternas.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    lateinit var consulta:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding=ActivityMainBinding.inflate(layoutInflater)
        consulta=binding.consulta
        setContentView(binding.root)
    }

    fun ejecutarServicios(view: View){
        val url="http://192.168.56.1/aplicacion/consulta.php"
        val cola=Volley.newRequestQueue(this)
        val StringRequest = StringRequest(Request.Method.GET, url,Response.Listener<String>
        { response -> consulta.text= "Respuesta: "+response.toString()
        },
            Response.ErrorListener {consulta.text= "Puede existir un error"} )
        cola.add(StringRequest)

    }
}