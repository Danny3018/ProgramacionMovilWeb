package com.example.androidexternas

import android.app.VoiceInteractor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.textclassifier.TextSelection
import android.widget.EditText
import android.widget.TextView
import com.android.volley.Response
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.androidexternas.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    lateinit var enviarnombre:EditText
    lateinit var valor:TextView
    lateinit var enviarapellido:EditText
    lateinit var enviarid:EditText
    lateinit var enviarcelular:EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding=ActivityMainBinding.inflate(layoutInflater)
        enviarnombre=binding.nombre
        valor = binding.valor
        enviarapellido  = binding.apellidos
        enviarid = binding.identificacion
        enviarcelular = binding.celular

        setContentView(binding.root)
    }

    fun ejecutarServicios(view: View){
        //val url="http://192.168.56.1/recibir/agregar_clienteMobil.php?nombre="+enviarnombre.text.toString()
        val url="http://192.168.1.4/ProgramacionMobilWeb/Models/agregar_clienteMobil.php?nombre="+enviarnombre.text.toString()+"&apellido="+enviarapellido.text.toString()+"&identificacion="+
                enviarid.text.toString()+"&celular="+enviarcelular.text.toString()
        val cola=Volley.newRequestQueue(this)
        val StringRequest = StringRequest(Request.Method.GET, url,Response.Listener<String>
        {
                response -> valor.text="**" +response.toString()
        },
            Response.ErrorListener {valor.setText("error")} )

        cola.add(StringRequest)

    }
}